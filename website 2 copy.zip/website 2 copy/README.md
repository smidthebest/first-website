# first-website
Has a simple Node.js file which uses a localhost to start a server that displays an html page. Asks for email and password and stores it in a local mysql server. redirects to a different page. 

https://www.freecodecamp.org/news/building-a-chat-application-with-mean-stack-637254d1136d/
